package com.yy.executor;

import com.yy.entity.User;

public interface Executor {
    <T> T query(String sql,Object o);
}
