package com.yy.executor;

import com.yy.entity.User;

import java.sql.*;

public class SimpleExecutor implements Executor {

    @Override
    public <T> T query(String sql, Object o) {
        Connection c = getConnection();
        try {
            PreparedStatement statement=c.prepareStatement(sql);
            statement.setInt(1,(Integer) o);
            ResultSet resultSet = statement.executeQuery();
            User u=null;
            while(resultSet.next()){
                u=new User();
                u.setId(resultSet.getInt("id"));
                u.setUsername(resultSet.getString("username"));
                u.setPassword(resultSet.getString("password"));
            }
            return (T)u;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    public Connection getConnection(){
        String driver="com.mysql.jdbc.Driver";
        String url="jdbc:mysql://localhost:3306/user?useSSL=false&serverTimezone=UTC";
        String username="root";
        String password="root";
        try {
            Class.forName(driver);
            Connection c= DriverManager.getConnection(url,username,password);
            return c;
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
