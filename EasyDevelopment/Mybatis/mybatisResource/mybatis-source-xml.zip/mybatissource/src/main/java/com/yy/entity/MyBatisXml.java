package com.yy.entity;

import java.util.HashMap;
import java.util.Map;

public class MyBatisXml {
    public static String namespace="com.yy.mapper.UserMapper";
    public static Map<String,String> map=new HashMap<>();
    static {
        map.put("selectById","select * from users where id = ?");
    }
}
