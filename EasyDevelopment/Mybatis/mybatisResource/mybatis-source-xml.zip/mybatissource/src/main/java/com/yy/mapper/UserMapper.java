package com.yy.mapper;

import com.yy.entity.User;

public interface UserMapper {
    User selectById(int id);
}
