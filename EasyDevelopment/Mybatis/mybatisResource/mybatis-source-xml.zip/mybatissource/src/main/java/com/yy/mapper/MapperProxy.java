package com.yy.mapper;

import com.yy.entity.MyBatisXml;
import com.yy.executor.SqlSession;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

public class MapperProxy implements InvocationHandler {
    private SqlSession sqlSession;
    public MapperProxy(SqlSession sqlSession){
        this.sqlSession=sqlSession;
    }
    @Override
    public Object invoke(Object proxy, Method method, Object[] args)  {
        if(method.getDeclaringClass().getName().equals(MyBatisXml.namespace)){
            String sql = MyBatisXml.map.get(method.getName());
             return sqlSession.selectOne(sql,args[0]);
        }
        return null;
    }
}
