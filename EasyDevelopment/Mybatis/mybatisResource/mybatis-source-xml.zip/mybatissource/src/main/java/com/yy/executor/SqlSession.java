package com.yy.executor;

import com.yy.mapper.MapperProxy;

import java.lang.reflect.Proxy;

public class SqlSession {
private Executor e=new SimpleExecutor();
public <T> T selectOne(String sql,Object o){
    return e.query(sql,o);
}
public <T> T getMapper(Class<T> tClass){
//第一个参数:类加载器,在类类型上调用getClassLoader()方法是得到当前类型的类加载器，我们知道在Java中所有的类都是通过加载器加载到虚拟机中的
    //第二个参数:the list of interfaces for the proxy class to implement
    //第三个参数:InvocationHandler动态代理
    //因为被代理的接口是UserMapper,所以需要UserMapper的类加载器
    return (T) Proxy.newProxyInstance(tClass.getClassLoader(),new Class[]{tClass},new MapperProxy(this));
}
}
