package com.yy;

import com.yy.entity.User;
import com.yy.executor.SqlSession;
import com.yy.mapper.UserMapper;
import org.junit.Test;

public class MyTest {
    @Test
    public void test01(){
        SqlSession session=new SqlSession();
        UserMapper mapper = session.getMapper(UserMapper.class);
        User user = mapper.selectById(1);
        System.out.println(user);
    }
}
