
#### 运行

右键 AppRunnableConfig > Run As > Java Application
