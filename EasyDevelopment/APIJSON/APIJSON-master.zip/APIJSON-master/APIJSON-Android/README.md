# APIJSON前端部署 - Android 

### 1.下载后解压APIJSON工程<h3/>

[打开APIJSON的GitHub主页](https://github.com/TommyLemon/APIJSON) &gt; Clone or download &gt; [Download ZIP](https://github.com/TommyLemon/APIJSON/archive/master.zip) &gt; 解压到一个路径并记住这个路径。

<br />

### 2.用Android Studio运行Android工程<h3/>


如果IDE没安装，运行前先下载安装。<br />
我的配置是Windows 7 + JDK 1.7.0_71 + Android Studio 2.2 和 OSX EI Capitan + JDK 1.8.0_91 + Android Studio 3.0，其中系统和软件都是64位的。

1)打开<br />
Open an existing Android Studio project > 选择刚才解压路径下的APIJSON-Master/APIJSON-Android/APIJSONApp （或APIJSONTest） > OK

2)运行<br />
Run > Run app

<br />

### 3.测试接口<h3/>

选择发送APIJSON请求并等待显示结果。<br />
如果默认url不可用，修改为一个可用的，比如正在运行APIJSON后端工程的电脑的IPV4地址，然后点击查询按钮重新请求。

<br />
