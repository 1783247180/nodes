create view VW_REGION as
  select "REGION_ID","REGION_NAME" from regions
/

